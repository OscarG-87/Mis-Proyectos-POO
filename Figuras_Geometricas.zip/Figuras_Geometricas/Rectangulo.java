/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Figuras_Geometricas;

/**
 *
 * @author Oscar
 */
public class Rectangulo {
        private String color = "rojo";
        private String descr = "tiene cuatro lados, dos de ellos de la misma longitud y en lado opuesto";
        
        public String getcolor() {
        return color;
    }

    public String getdescr() {
        return descr;
    }

    public void setcolor(String color) {
        this.color = color;
    }

    public void setdescr(int lado1) {
        this.descr = descr;
    }

    
}
