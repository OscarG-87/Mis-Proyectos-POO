/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Figuras_Geometricas;

/**
 *
 * @author Oscar
 */
public class Triangulo {
    private String color = "amarilllo";   
    private String descr = "tiene tres lados, algunos de ellos pueden ser iguales";

    private int lado1;
    private int lado2;
    private int lado3;
    
   public String getcolor() {
        return color;
    }

    public String getdescr() {
        return descr;
    }

    public void setcolor(String color) {
        this.color = color;
    }

    public void setdescr(int lado1) {
        this.descr = descr;
    }
    
    
    
}
