
package Figuras_Geometricas;


public class Cuadrado {

    private String color = "azul";
    private String descr = "tiene cuatro lados iguales los cuales forman cuatro angulos rectos";
    public int perimetro;

   

    public String getcolor() {
        return color;
    }

    public String getdescr() {
        return descr;
    }

    public void setcolor(String color) {
        this.color = color;
    }

    public void setdescr(int lado1) {
        this.descr = descr;
    }
}
