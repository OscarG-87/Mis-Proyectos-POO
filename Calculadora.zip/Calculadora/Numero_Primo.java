package Calculadora;

public class Numero_Primo {

    public boolean primo = true;
    public int contador = 2;

    public boolean esPrimo(int numero) {
        while ((primo) && (contador != numero)) {

            if (numero % contador == 0) {
                primo = false;
            }
            contador++;
            if (numero % 2 == 0) {
                primo= false;
            }
            return primo;
        }
    return primo;
    }
}
