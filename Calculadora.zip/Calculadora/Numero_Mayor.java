
package Calculadora;


public class Numero_Mayor {

    public int num1;
    public int num2;
    public int num3;
    public int num4;
    public int resultado;

    public int nmayor(int n1, int n2, int n3, int n4) {
        num1 = n1;
        num1 = n2;
        num1 = n3;
        num1 = n4;

        if (n1 > n2 && n1 > n3 && n1 > n4) {
            resultado = n1;
            System.out.println("El número mayor es "+resultado);
        } else if (n1 < n2 && n2 > n3 && n2 > n4) {
            resultado = n2;
            System.out.println("El número mayor es "+resultado);
        } else if (n1 < n3 && n2 < n3 && n3 > n4) {
            resultado = n3;
            System.out.println("El número mayor es "+resultado);
        } else if (n1 < n4 && n2 < n4 && n3 < n4) {
            resultado = n4;
            System.out.println("El número mayor es "+resultado);
        }
    
    return resultado;
    }
}
