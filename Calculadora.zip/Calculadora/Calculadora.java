/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Calculadora;

import java.util.Scanner;

/**
 *
 * @author Oscar
 */
public class Calculadora {

    public static void main(String[] args) {
        int resultado;
        System.out.println("Seleccione la opción correspondiente: " + "\n" + "1 Sumar" + "\n" + "2 Restar" + "\n" + "3 Multiplicar"
                + "\n" + "4 Dividir" + "\n" + "5 Validar número primo" + "\n" + "6 Validar el mayor de 4 números");
        Scanner op = new Scanner(System.in);
        String opc = op.nextLine();
        int opcion = Integer.parseInt(opc);
        if (opcion <= 6);
        {

            if (opcion == 1) {
                System.out.println("¡Vamos a sumar dos enteros! ");
                System.out.println("Digite el primer número: ");
                Scanner n1 = new Scanner(System.in);
                String sn1 = n1.nextLine();
                int num1 = Integer.parseInt(sn1);
                System.out.println("Digite el segundo número: ");
                Scanner n2 = new Scanner(System.in);
                String sn2 = n2.nextLine();
                int num2 = Integer.parseInt(sn2);

                Suma suma = new Suma();
                {
                    suma.sumar(num1, num2);
                    System.out.println("EL resultado es " + suma.resultado);
                }
            } else if (opcion == 2) {
                System.out.println("¡Vamos a restar dos enteros! ");
                System.out.println("Digite el primer número: ");
                Scanner n1 = new Scanner(System.in);
                String r1 = n1.nextLine();
                int num1 = Integer.parseInt(r1);
                System.out.println("Digite el segundo número: ");
                Scanner n2 = new Scanner(System.in);
                String r2 = n2.nextLine();
                int num2 = Integer.parseInt(r2);

                Resta resta = new Resta();
                {
                    resta.restar(num1, num2);
                    System.out.println("El resultado es " + resta.resultado);

                }
            } else if (opcion == 3) {
                System.out.println("¡Vamos a multiplicar dos enteros! ");
                System.out.println("Digite el primer número: ");
                Scanner n1 = new Scanner(System.in);
                String r1 = n1.nextLine();
                int num1 = Integer.parseInt(r1);
                System.out.println("Digite el segundo número: ");
                Scanner n2 = new Scanner(System.in);
                String m2 = n2.nextLine();
                int num2 = Integer.parseInt(m2);

                Multiplicacion multi = new Multiplicacion();
                {
                    multi.multiplicar(num1, num2);
                    System.out.println("El resultado es " + multi.resultado);

                }
            } else if (opcion == 4) {
                System.out.println("¡Vamos a dividir dos enteros! ");
                System.out.println("Digite el primer número: ");
                Scanner n1 = new Scanner(System.in);
                String d1 = n1.nextLine();
                int num1 = Integer.parseInt(d1);
                System.out.println("Digite el segundo número: ");
                Scanner n2 = new Scanner(System.in);
                String d2 = n2.nextLine();
                int num2 = Integer.parseInt(d2);

                Division divi = new Division();
                {
                    divi.dividir(num1, num2);
                    System.out.println("El resultado es " + divi.resultado);

                }

            } else if (opcion == 5) {
                System.out.println("¡Vamos a validar si el número es primo! ");
                System.out.println("Digite un núero entero: ");
                Scanner n1 = new Scanner(System.in);
                String p1 = n1.nextLine();
                int num = Integer.parseInt(p1);

                Numero_Primo primo = new Numero_Primo();
                {
                    primo.esPrimo(num);
                    {
                        if (primo.primo == true) {
                            System.out.println("El número " + num + " es primo");
                        } else {
                            System.out.println("El número " + num + " no es primo");

                        }
                    }

                }
            } else if (opcion == 6) {
                System.out.println("¡Vamos a validar el numero mayor de 4 enteros! ");
                System.out.println("Digite el primer número entero: ");
                Scanner n1 = new Scanner(System.in);
                String m1 = n1.nextLine();
                int num1 = Integer.parseInt(m1);
                System.out.println("Digite el segundo número entero: ");
                Scanner n2 = new Scanner(System.in);
                String m2 = n2.nextLine();
                int num2 = Integer.parseInt(m2);
                System.out.println("Digite el tercer número entero: ");
                Scanner n3 = new Scanner(System.in);
                String m3 = n3.nextLine();
                int num3 = Integer.parseInt(m3);
                System.out.println("Digite el cuarto número entero: ");
                Scanner n4 = new Scanner(System.in);
                String m4 = n4.nextLine();
                int num4 = Integer.parseInt(m4);

                Numero_Mayor mayor = new Numero_Mayor();
                {
                    mayor.nmayor(num1, num2, num3, num4);

                }
            }else{
               System.out.println("¡Opción incorrecta!"); 
            }
            
            
        }
    }
}
