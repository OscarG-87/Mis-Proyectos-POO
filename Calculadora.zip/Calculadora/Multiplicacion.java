
package Calculadora;


public class Multiplicacion {
    public int num1;
    public int num2;
    public int resultado;

           
    
    public int multiplicar (int n1,int n2){  
        num1=n1;
        num2 =n2;
        resultado = num1 * num2;
        return resultado;
    
}
